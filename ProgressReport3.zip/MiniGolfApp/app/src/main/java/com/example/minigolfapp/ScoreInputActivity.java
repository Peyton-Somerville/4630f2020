package com.example.minigolfapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ScoreInputActivity extends AppCompatActivity {

    int boxNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_input);

        Intent intent = getIntent();
        boxNum = intent.getIntExtra("boxNum", 0);
    }

    /** Called when the user chooses a score */
    public void sendScore(View view) {
        Intent intent = new Intent(this, ScorecardActivity.class);

        switch (view.getId()) {
            case R.id.button1:
                intent.putExtra("score", "1");
                break;
            case R.id.button2:
                intent.putExtra("score", "2");
                break;
            case R.id.button3:
                intent.putExtra("score", "3");
                break;
            case R.id.button4:
                intent.putExtra("score", "4");
                break;
            case R.id.button5:
                intent.putExtra("score", "5");
                break;
            case R.id.button6:
                intent.putExtra("score", "6");
                break;
            case R.id.button7:
                intent.putExtra("score", "7");
                break;
            case R.id.button8:
                intent.putExtra("score", "8");
                break;
            default:
                break;
        }

        intent.putExtra("boxNum", boxNum);
        startActivity(intent);
    }

    /** Called when the user taps the back button */
    public void backToScorecard(View view) {
        Intent intent = new Intent(this, ScorecardActivity.class);
        startActivity(intent);
    }
}
