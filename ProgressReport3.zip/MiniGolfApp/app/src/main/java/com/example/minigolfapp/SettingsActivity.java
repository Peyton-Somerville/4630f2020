package com.example.minigolfapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    EditText edTxtStrLim;
    EditText edTxtStrPen;
    Button btnSave;

    String strLim = "8";
    String strPen = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        edTxtStrLim = findViewById(R.id.editTxtStrLim);
        edTxtStrPen = findViewById(R.id.editTxtStrPen);
        btnSave = findViewById(R.id.btnSave);

        SharedPreferences settings = getSharedPreferences("settings", 0);
        strLim = settings.getString("strokeLim", "");
        strPen = settings.getString("strokePen", "");
        edTxtStrLim.setText(strLim);
        edTxtStrPen.setText(strPen);
    }

    /** Called when the user taps the save button */
    public void saveSettings(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("settings", 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("strokeLim", edTxtStrLim.getText().toString());
        editor.putString("strokePen", edTxtStrPen.getText().toString());
        editor.apply();

        Toast.makeText(SettingsActivity.this, "Settings Saved", Toast.LENGTH_LONG).show();
    }

    /** Called when the user taps the back button */
    public void backToScorecard(View view) {
        //Bundle settings = new Bundle();
        //settings.putString("strokeLim", edTxtStrLim.getText().toString());
        //settings.putString("strokePen", edTxtStrPen.getText().toString());

        Intent intent = new Intent(this, ScorecardActivity.class);
        //intent.putExtras(settings);

        startActivity(intent);
    }
}
