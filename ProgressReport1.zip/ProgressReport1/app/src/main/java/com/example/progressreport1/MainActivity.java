package com.example.progressreport1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;

public class MainActivity extends AppCompatActivity {

    Button btn11;
    Button btn12;
    Button btn13;
    Button btn14;

    Button btn21;
    Button btn22;
    Button btn23;
    Button btn24;

    Button btn31;
    Button btn32;
    Button btn33;
    Button btn34;

    Button btn41;
    Button btn42;
    Button btn43;
    Button btn44;

    Button btn51;
    Button btn52;
    Button btn53;
    Button btn54;

    Button btn61;
    Button btn62;
    Button btn63;
    Button btn64;

    Button btn71;
    Button btn72;
    Button btn73;
    Button btn74;

    Button btn81;
    Button btn82;
    Button btn83;
    Button btn84;

    Button btn91;
    Button btn92;
    Button btn93;
    Button btn94;

    Button btn101;
    Button btn102;
    Button btn103;
    Button btn104;

    Button btn111;
    Button btn112;
    Button btn113;
    Button btn114;

    Button btn121;
    Button btn122;
    Button btn123;
    Button btn124;

    Button btn131;
    Button btn132;
    Button btn133;
    Button btn134;

    Button btn141;
    Button btn142;
    Button btn143;
    Button btn144;

    Button btn151;
    Button btn152;
    Button btn153;
    Button btn154;

    Button btn161;
    Button btn162;
    Button btn163;
    Button btn164;

    Button btn171;
    Button btn172;
    Button btn173;
    Button btn174;

    Button btn181;
    Button btn182;
    Button btn183;
    Button btn184;

    String score;
    int boxNum;

    TableLayout scoreSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scoreSelect = findViewById(R.id.tableScoreSelect);

        btn11 = findViewById(R.id.button11);
        btn12 = findViewById(R.id.button12);
        btn13 = findViewById(R.id.button13);
        btn14 = findViewById(R.id.button14);

        btn21 = findViewById(R.id.button21);
        btn22 = findViewById(R.id.button22);
        btn23 = findViewById(R.id.button23);
        btn24 = findViewById(R.id.button24);

        btn31 = findViewById(R.id.button31);
        btn32 = findViewById(R.id.button32);
        btn33 = findViewById(R.id.button33);
        btn34 = findViewById(R.id.button34);

        btn41 = findViewById(R.id.button41);
        btn42 = findViewById(R.id.button42);
        btn43 = findViewById(R.id.button43);
        btn44 = findViewById(R.id.button44);

        btn51 = findViewById(R.id.button51);
        btn52 = findViewById(R.id.button52);
        btn53 = findViewById(R.id.button53);
        btn54 = findViewById(R.id.button54);

        btn61 = findViewById(R.id.button61);
        btn62 = findViewById(R.id.button62);
        btn63 = findViewById(R.id.button63);
        btn64 = findViewById(R.id.button64);

        btn71 = findViewById(R.id.button71);
        btn72 = findViewById(R.id.button72);
        btn73 = findViewById(R.id.button73);
        btn74 = findViewById(R.id.button74);

        btn81 = findViewById(R.id.button81);
        btn82 = findViewById(R.id.button82);
        btn83 = findViewById(R.id.button83);
        btn84 = findViewById(R.id.button84);

        btn91 = findViewById(R.id.button91);
        btn92 = findViewById(R.id.button92);
        btn93 = findViewById(R.id.button93);
        btn94 = findViewById(R.id.button94);

        btn101 = findViewById(R.id.button101);
        btn102 = findViewById(R.id.button102);
        btn103 = findViewById(R.id.button103);
        btn104 = findViewById(R.id.button104);

        btn111 = findViewById(R.id.button111);
        btn112 = findViewById(R.id.button112);
        btn113 = findViewById(R.id.button113);
        btn114 = findViewById(R.id.button114);

        btn121 = findViewById(R.id.button121);
        btn122 = findViewById(R.id.button122);
        btn123 = findViewById(R.id.button123);
        btn124 = findViewById(R.id.button124);

        btn131 = findViewById(R.id.button131);
        btn132 = findViewById(R.id.button132);
        btn133 = findViewById(R.id.button133);
        btn134 = findViewById(R.id.button134);

        btn141 = findViewById(R.id.button141);
        btn142 = findViewById(R.id.button142);
        btn143 = findViewById(R.id.button143);
        btn144 = findViewById(R.id.button144);

        btn151 = findViewById(R.id.button151);
        btn152 = findViewById(R.id.button152);
        btn153 = findViewById(R.id.button153);
        btn154 = findViewById(R.id.button154);

        btn161 = findViewById(R.id.button161);
        btn162 = findViewById(R.id.button162);
        btn163 = findViewById(R.id.button163);
        btn164 = findViewById(R.id.button164);

        btn171 = findViewById(R.id.button171);
        btn172 = findViewById(R.id.button172);
        btn173 = findViewById(R.id.button173);
        btn174 = findViewById(R.id.button174);

        btn181 = findViewById(R.id.button181);
        btn182 = findViewById(R.id.button182);
        btn183 = findViewById(R.id.button183);
        btn184 = findViewById(R.id.button184);
    }

    /** Called when the user taps a score box */
    public void sendToScoreInput(View view) {
       /* Intent intent = new Intent(this, ScoreInputActivity.class);
        intent.putExtra("boxNum", view.getId());
        startActivity(intent); */
        scoreSelect.setVisibility(View.VISIBLE);
        boxNum = view.getId();
    }

    public void scoreInput(View view) {
        scoreSelect.setVisibility(View.INVISIBLE);

        switch(view.getId()) {
            case R.id.btnScore1:
                score = "1";
                break;
            case R.id.btnScore2:
                score = "2";
                break;
            case R.id.btnScore3:
                score = "3";
                break;
            case R.id.btnScore4:
                score = "4";
                break;
            case R.id.btnScore5:
                score = "5";
                break;
            case R.id.btnScore6:
                score = "6";
                break;
            case R.id.btnScore7:
                score = "7";
                break;
            case R.id.btnScore8:
                score = "8";
                break;
            default:
                break;
        }

        switch (boxNum) {
            case R.id.button11:
                btn11.setText(score);
                break;
            case R.id.button12:
                btn12.setText(score);
                break;
            case R.id.button13:
                btn13.setText(score);
                break;
            case R.id.button14:
                btn14.setText(score);
                break;

            case R.id.button21:
                btn21.setText(score);
                break;
            case R.id.button22:
                btn22.setText(score);
                break;
            case R.id.button23:
                btn23.setText(score);
                break;
            case R.id.button24:
                btn24.setText(score);
                break;

            case R.id.button31:
                btn31.setText(score);
                break;
            case R.id.button32:
                btn32.setText(score);
                break;
            case R.id.button33:
                btn33.setText(score);
                break;
            case R.id.button34:
                btn34.setText(score);
                break;

            case R.id.button41:
                btn41.setText(score);
                break;
            case R.id.button42:
                btn42.setText(score);
                break;
            case R.id.button43:
                btn43.setText(score);
                break;
            case R.id.button44:
                btn44.setText(score);
                break;

            case R.id.button51:
                btn51.setText(score);
                break;
            case R.id.button52:
                btn52.setText(score);
                break;
            case R.id.button53:
                btn53.setText(score);
                break;
            case R.id.button54:
                btn54.setText(score);
                break;

            case R.id.button61:
                btn61.setText(score);
                break;
            case R.id.button62:
                btn62.setText(score);
                break;
            case R.id.button63:
                btn63.setText(score);
                break;
            case R.id.button64:
                btn64.setText(score);
                break;

            case R.id.button71:
                btn71.setText(score);
                break;
            case R.id.button72:
                btn72.setText(score);
                break;
            case R.id.button73:
                btn73.setText(score);
                break;
            case R.id.button74:
                btn74.setText(score);
                break;

            case R.id.button81:
                btn81.setText(score);
                break;
            case R.id.button82:
                btn82.setText(score);
                break;
            case R.id.button83:
                btn83.setText(score);
                break;
            case R.id.button84:
                btn84.setText(score);
                break;

            case R.id.button91:
                btn91.setText(score);
                break;
            case R.id.button92:
                btn92.setText(score);
                break;
            case R.id.button93:
                btn93.setText(score);
                break;
            case R.id.button94:
                btn94.setText(score);
                break;

            case R.id.button101:
                btn101.setText(score);
                break;
            case R.id.button102:
                btn102.setText(score);
                break;
            case R.id.button103:
                btn103.setText(score);
                break;
            case R.id.button104:
                btn104.setText(score);
                break;

            case R.id.button111:
                btn111.setText(score);
                break;
            case R.id.button112:
                btn112.setText(score);
                break;
            case R.id.button113:
                btn113.setText(score);
                break;
            case R.id.button114:
                btn114.setText(score);
                break;

            case R.id.button121:
                btn121.setText(score);
                break;
            case R.id.button122:
                btn122.setText(score);
                break;
            case R.id.button123:
                btn123.setText(score);
                break;
            case R.id.button124:
                btn124.setText(score);
                break;

            case R.id.button131:
                btn131.setText(score);
                break;
            case R.id.button132:
                btn132.setText(score);
                break;
            case R.id.button133:
                btn133.setText(score);
                break;
            case R.id.button134:
                btn134.setText(score);
                break;

            case R.id.button141:
                btn141.setText(score);
                break;
            case R.id.button142:
                btn142.setText(score);
                break;
            case R.id.button143:
                btn143.setText(score);
                break;
            case R.id.button144:
                btn144.setText(score);
                break;

            case R.id.button151:
                btn151.setText(score);
                break;
            case R.id.button152:
                btn152.setText(score);
                break;
            case R.id.button153:
                btn153.setText(score);
                break;
            case R.id.button154:
                btn154.setText(score);
                break;

            case R.id.button161:
                btn161.setText(score);
                break;
            case R.id.button162:
                btn162.setText(score);
                break;
            case R.id.button163:
                btn163.setText(score);
                break;
            case R.id.button164:
                btn164.setText(score);
                break;

            case R.id.button171:
                btn171.setText(score);
                break;
            case R.id.button172:
                btn172.setText(score);
                break;
            case R.id.button173:
                btn173.setText(score);
                break;
            case R.id.button174:
                btn174.setText(score);
                break;

            case R.id.button181:
                btn181.setText(score);
                break;
            case R.id.button182:
                btn182.setText(score);
                break;
            case R.id.button183:
                btn183.setText(score);
                break;
            case R.id.button184:
                btn184.setText(score);
                break;

            default:
                break;
        }
    }
}

