package com.example.assignment4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    int clickCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount = clickCount + 1;

                TextView text = (TextView) findViewById((R.id.textView1));

                if(clickCount == 1){
                    text.setText("Button has been clicked");
                }
                else if (clickCount > 1 && clickCount < 30){
                    text.setText("Button has been clicked x" +clickCount);
                }
                else{
                    text.setText("Wow, you clicked the button a lot...");
                }
            }
        });
    }

    public void sendToWeather(View v) {
        Intent i = new Intent(this, WeatherActivity.class);
        startActivity(i);
    }
}
