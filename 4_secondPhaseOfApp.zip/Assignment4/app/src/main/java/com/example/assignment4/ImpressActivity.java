package com.example.assignment4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ImpressActivity extends AppCompatActivity {

    int next = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_impress);

        Button button = findViewById(R.id.btnNext);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView txt = (TextView) findViewById((R.id.txtImpress));

                if(next == 0){
                    txt.setText("Double it.");
                }
                else if(next == 1){
                    txt.setText("Add 9.");
                }
                else if(next == 2){
                    txt.setText("Subtract 3.");
                }
                else if(next == 3){
                    txt.setText("Divide by 2.");
                }
                else if(next == 4){
                    txt.setText("Subtract your original number.");
                }
                else if(next == 5){
                    txt.setText("Got your final answer?");
                }
                else if(next == 6){
                    txt.setText("I bet your final number is 3.");
                }

                next++;
            }
        });
    }
}
